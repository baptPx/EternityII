package com.bapt.eternity;

import java.util.LinkedList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import Tools.Camera;
import Tools.Fonction;
import Tools.res;
import Tools.zoneInterface;

public class InGameScreen implements Screen {


	private SpriteBatch batch, batchI;
	private Camera cam;
	private Piece map[][], pieceS, pieceSwap, pieceN;
	private List<Piece> piece;
	private zoneInterface newPiece, showAll, buildPiece, getBack, choiseW[], choiseH[], makeLevel, rightRotation, leftRotation;
	private String pos;
	private float x, y, touchX, touchY, oldX, oldY, oldDistance, distance;
	private float selection[];
	private BitmapFont font;
	private Eternity game;
	private boolean justTouched1, canPlay;
	
	private List<Piece> readPieceCSV(String file)
	{
		List<Piece> pieces = new LinkedList<Piece>();	// creation de la liste
		FileHandle fichier = Gdx.files.internal(file);	// lecture du fichier 
		byte[] contenu = fichier.readBytes();		

		int index=0, line = 0, info = 0;
		int q[] = new int[5];
		for(byte i=0;i<5;i++)	// initialisation des valeurs des coté a 0
			q[i]=0;
		for(index=0; line<2; index++)
			if(contenu[index] == 10)
				line++;					// Passage des 2 premieres lignes (en t�te du fichier)
		for(;index<fichier.length();index++)
		{
			if(contenu[index]>= 48 && contenu[index]<=57)	// stockage de l'information dans le tableau d'entier
			{
				q[info%5]+=contenu[index] - 48;
				q[info%5]*=10;
			}
			else if(contenu[index] == 10 || contenu[index] == 44)	// saut de ligne ou changement d'information
			{	
				q[info%5]/=10;
				info++;
				if(contenu[index] == 10)	// saut de ligne, ajout de la piece, reinitialisation des valeurs du tableau d'entier.
				{
					pieces.add(new Piece((byte)q[1], (byte)q[2], (byte)q[3], (byte)q[4]));
					for(int i=0; i<5; i++)
						q[i]=0;
				}
			}
		}
		return pieces;
	}
	
	private List<Piece> readPieceETY(String file)
	{
		List<Piece> pieces = new LinkedList<Piece>();	// creation de la liste
		FileHandle fichier = Gdx.files.internal(file);	// lecture du fichier 
		byte[] contenu = fichier.readBytes();		
		map = new Piece[contenu[0]][contenu[1]];
		for(byte i=0; i<contenu[0];i++)
			for(byte j=0; j<contenu[1];j++)
				map[i][j] = pieceN;
		for(int i=2;i<contenu.length;i+=4)
			pieces.add(new Piece(contenu[i], contenu[i+1], contenu[i+2], contenu[i+3]));
		return pieces;
	}
	@Override
	public void show() {

		canPlay = true;
		justTouched1=false;
		font = new BitmapFont();
		selection = new float[2];	
		selection[0] = -1; selection[1] =-1;
		piece = null;
		pieceSwap = null;
		pieceN = new Piece((byte)1);
		map = new Piece[16][16];
		for(int i=0; i<16; i++)
			for(int j=0; j<16; j++)
				map[i][j] = pieceN;		// on rempli le tterrain de piece "vide"

		piece = new LinkedList<Piece>();
		piece = readPieceETY("lvl/lvl.ety");
	
		batch = new SpriteBatch();
		batchI = new SpriteBatch();
		cam = new Camera();
		
		newPiece = new zoneInterface(0f, 0f, 100f, 20f, Color.BLUE);
		getBack = new zoneInterface(0f, 0f, 100f, 20f, Color.BLACK);
		leftRotation = new zoneInterface(20, 0f, 30, 20f, Color.BROWN);
		rightRotation = new zoneInterface(50, 0f, 30, 20f, Color.GOLD);
		makeLevel = new zoneInterface(0f, 0f, 100f, 20f, Color.GREEN);
		showAll = new zoneInterface(0f, 20f, 50, 80, Color.ORANGE);
		buildPiece = new zoneInterface(50, 20f, 50, 80, Color.CYAN);
		newPiece.setTextMidV();
		newPiece.setTextMidH();
		newPiece.setText("Ajout� une nouvelle piece");
		getBack.setTextMidV();
		getBack.setTextMidH();
		getBack.setText("get Back");
		showAll.setTextMidV();
		showAll.setTextMidH();
		showAll.setText("Show All !");
		buildPiece.setTextMidV();
		buildPiece.setTextMidH();
		buildPiece.setText("Build Piece !");
		makeLevel.setTextMidV();
		makeLevel.setTextMidH();
		makeLevel.setText("Commencer");		
		
		choiseW = new zoneInterface[10];
		choiseH = new zoneInterface[10];
		for(int i=0; i<10; i++)
		{	
			choiseW[i] = new zoneInterface((float)i/10*100, 90, 100/10, 10, Fonction.getDegrade(0.05f, 0.96f, 0.33f, 1, 0, 0.01f, (float)i/10));
			choiseW[i].setText(""+(int)(i+1)*2);
			choiseW[i].setTextMidH();
			choiseW[i].setTextMidV();
			choiseH[i] = new zoneInterface((float)i/10*100, 75, 100/10, 10, Fonction.getDegrade(0.05f, 0.96f, 0.33f, 1, 0, 0.01f, (float)i/10));
			choiseH[i].setText(""+(int)(i+1)*2);
			choiseH[i].setTextMidH();
			choiseH[i].setTextMidV();
		}
		pos = "jeu";	
	}
	
	public InGameScreen(Eternity game) {
		this.game = game;
	}
	
	public void menuMake(float delta)
	{
		for(int i=0; i<choiseW.length; i++)
		{
			choiseW[i].update(delta);
			choiseH[i].update(delta);
		}
		makeLevel.update(delta);
		batchI.begin();
		for(int i=0; i<10; i++)
		{
			choiseW[i].draw(batchI);
			choiseH[i].draw(batchI);
		}
		font.draw(batchI, "Largeur", Gdx.graphics.getWidth()/2 - 20, Gdx.graphics.getHeight() - font.getAscent() - Gdx.graphics.getHeight()/100*10);
		font.draw(batchI, "Longueur", Gdx.graphics.getWidth()/2 - 22, Gdx.graphics.getHeight() - font.getAscent() - Gdx.graphics.getHeight()/100*25);
		makeLevel.draw(batchI);
		batchI.end();
		for(int i=0;i<10;i++)
		{
			if(choiseW[i].isJustTouched())
			{
				choiseW[i].setColorAlpha(1);
				for(int j=0;j<10;j++)
					if(j!=i)
						choiseW[j].setColorAlpha(0.4f);
			}
			if(choiseH[i].isJustTouched())
			{
				choiseH[i].setColorAlpha(1);
				for(int j=0;j<10;j++)
					if(j!=i)
						choiseH[j].setColorAlpha(0.4f);
			}
		}
	}
	
	public void jeu(float delta){

		
		newPiece.update(delta);
		rightRotation.update(delta);
		leftRotation.update(delta);
		for(int i=0; i<piece.size(); i++)
			piece.get(i).update(delta);

		
		
		if(newPiece.isJustTouched() && pieceS == null)
			pos = "newPiece1";
		else if(Gdx.input.justTouched())
		{
			selection[0] = touchX;
			selection[1] = touchY;

		}

		else if(selection[1]<Gdx.graphics.getHeight()*0.8f && !Gdx.input.isTouched() && selection[0]!=-1 && Math.abs(selection[0] - touchX) < Gdx.graphics.getWidth()/10 && Math.abs(selection[1] - touchY) < Gdx.graphics.getHeight()/10) // si on viens seulement de relacher l'appui
		{					// et que nous avons pas trop bouger la souris donc que l'on souhaite effectuer un changement sur la map et non la déplacer
			if(pieceS != null)	// si une pièce est selectionner
			{
				if(map[(int)(x/130)][(int)(y/130)].isEmpty())	// si l'emplacement est vide on pose la pièce
				{
					map[(int)(x/130)][(int)(y/130)] = pieceS;
					pieceS = null;
				}
				
				else	// sinon, elle est posé, puis la pièce qui était déjà présente devient la pièce séléctionner
				{
					pieceSwap = pieceS;
					pieceS = map[(int)(x/130)][(int)(y/130)];
					map[(int)(x/130)][(int)(y/130)] = pieceSwap;
				}
			}
			else // s'il n'y a pas de pièce sélectionner
			{
				if(!map[(int)(x/130)][(int)(y/130)].isEmpty())	// si il y a une pièce a l'emplacement choisi, alors elle devient la pièce sélectionner
				{
					pieceS = map[(int)(x/130)][(int)(y/130)];
					map[(int)(x/130)][(int)(y/130)] = pieceN;

				}
				
			}
		}

		if(!Gdx.input.isTouched())	// pas d'appui
			selection[0] = -1;

		cam.position.x -= (touchX - oldX)*cam.zoom;
		cam.position.y += (touchY - oldY)*cam.zoom;

		if(pieceS != null)
		{
			if(Gdx.input.isKeyJustPressed(Keys.R) || rightRotation.isJustTouched())	
				pieceS.rightRotation();
			if(Gdx.input.isKeyJustPressed(Keys.E) || leftRotation.isJustTouched())	
				pieceS.leftRotation();	
			
			pieceS.update(delta);

		}
		batch.begin();
		for(int i=0 ; i<map.length; i++)
			for(int j=0; j<map[i].length; j++)
				map[i][j].draw(batch, i*130, j*130);

		if(pieceS != null)
			pieceS.draw(batch, cam.position.x - (Gdx.graphics.getWidth()/2)*cam.zoom + Gdx.input.getX() *cam.zoom - Piece.width/2, 
				 cam.position.y - (Gdx.graphics.getHeight()/2)*cam.zoom + (Gdx.graphics.getHeight() - Gdx.input.getY())  * cam.zoom - Piece.width/2);
		
		batch.end();
		
		batchI.begin();

		if(pieceS == null)
			newPiece.draw(batchI);
		else	{
			pieceS.draw(batchI, 0, 0);
			rightRotation.draw(batchI);
			leftRotation.draw(batchI);
		}
		batchI.end();
			
	}
	
	public void newPiece1(float delta) // menu selection entre voir tout et construire la piece
	{


		getBack.update(delta);
		showAll.update(delta);
		buildPiece.update(delta);
		batchI.begin();
		
		getBack.draw(batchI);
		showAll.draw(batchI);
		buildPiece.draw(batchI);
		
		batchI.end();
		
		if(getBack.isJustTouched())
			pos = "jeu";
		if(showAll.isJustTouched())
			pos = "newPiece2";
	}
	
	public void newPiece2(float delta)	// selection d'une piece parmis toutes celles qu'il y a 
	{

		getBack.update(delta);
		
		batch.begin();
		for(byte i=0 ; i<piece.size()/16; i++)
			for(byte j=0; j< (i < piece.size()/16 - 1 ? 16 : piece.size()%16) ; j++)
				piece.get(i*16 +j).draw(batch, i*150, j*150);			
		
		batch.end();
		
		batchI.begin();
		
		getBack.draw(batchI);
		
		batchI.end();
		
		if(getBack.isJustTouched())
			pos = "newPiece1";
		else if(Gdx.input.justTouched())
		{
			selection[0] = touchX;
			selection[1] = touchY;

		}
		if(!Gdx.input.isTouched() && selection[0]!=-1 && Math.abs(selection[0] - touchX) < Gdx.graphics.getWidth()/10 && Math.abs(selection[1] - touchY) < Gdx.graphics.getHeight()/10) // si on viens seulement de relacher l'appui
		{
			pieceS = piece.get((int)(x/150)*map.length + (int)(y/150));
			piece.remove((int)(x/150)*map.length + (int)(y/150));
			pos = "jeu";
		}

		if(!Gdx.input.isTouched())
			selection[0]=-1;
		else
		{
			cam.position.x -= (touchX - oldX)*cam.zoom;
			cam.position.y += (touchY - oldY)*cam.zoom;
		}
			
		
	}
	
	@Override
	public void render(float delta) 
	{
		cam.update();
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.setProjectionMatrix(cam.combined);
		

		if(Gdx.input.justTouched())
		{
			touchX = Gdx.input.getX(0);
			touchY = Gdx.input.getY(0);

		}

		oldX = touchX;
		oldY = touchY;
		 if(Gdx.input.isTouched())
		{
			touchX = Gdx.input.getX(0);
			touchY = Gdx.input.getY(0);
		}
		if(Gdx.input.isTouched(1) )
		{
			if(!justTouched1)
				distance = (float)Math.sqrt(	(Gdx.input.getX(1) - touchX) * (Gdx.input.getX(1) - touchX) + 	(Gdx.input.getY(1) - touchY) * (Gdx.input.getY(1) - touchY));
			oldDistance = distance;
			distance = (float)Math.sqrt(	(Gdx.input.getX(1) - touchX) * (Gdx.input.getX(1) - touchX) + 	(Gdx.input.getY(1) - touchY) * (Gdx.input.getY(1) - touchY));
			justTouched1 = true;
			cam.zoom -= (distance - oldDistance) / Gdx.graphics.getWidth();
		}
		else
			justTouched1 = false;

		x = cam.position.x + Gdx.input.getX()*cam.zoom - Gdx.graphics.getWidth()/2*(cam.zoom);
		y = cam.position.y + (Gdx.graphics.getHeight() - Gdx.input.getY())*cam.zoom - Gdx.graphics.getHeight()/2*cam.zoom;



		if(pos == "jeu")
			jeu(delta);
		else if (pos == "newPiece1")
			newPiece1(delta);
		else if (pos == "newPiece2")
			newPiece2(delta);
		else if (pos == "menuMake" ) 
			menuMake(delta);
			
	}


	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

}
