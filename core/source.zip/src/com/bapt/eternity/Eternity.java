package com.bapt.eternity;

import com.badlogic.gdx.Game;

import Tools.res;

public class Eternity extends Game {

	
	private InGameScreen screen;
	
	@Override
	public void create () {
		res.build();
		setScreen(new InGameScreen(this));
	
	}

	@Override
	public void render () {
		super.render();
	}
	
	@Override
	public void dispose () {
		super.dispose();
	}
	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		super.resize(width, height);
	}
}
